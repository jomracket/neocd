/**********************
 *     2xSaI.h        *
 **********************/

#include <SDL.h>

extern int Init_2xSaI (Uint32);
extern void Super2xSaI(void);
extern void SuperEagle(void);

extern SDL_Surface *delta;
